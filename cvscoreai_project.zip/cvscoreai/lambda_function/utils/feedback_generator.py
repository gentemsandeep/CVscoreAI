
import re

def generate_feedback(text, ai_response):
    score_match = re.search(r'score.*?(\d{1,3})', ai_response.lower())
    score = int(score_match.group(1)) if score_match else 70
    return score, ai_response
