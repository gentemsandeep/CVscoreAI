
import openai
import os

openai.api_key = os.getenv('OPENAI_API_KEY')

def analyze_resume(text):
    prompt = f"""
    You are an expert career advisor. Analyze the following resume text and provide:
    - Key strengths
    - Weaknesses
    - Missing skills
    - Overall score (out of 100)

    Resume:
    {text}
    """
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    )
    return response['choices'][0]['message']['content']
