
import json
import boto3
from utils.textract_handler import extract_text_from_s3
from utils.openai_handler import analyze_resume
from utils.feedback_generator import generate_feedback

def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    resume_text = extract_text_from_s3(bucket, key)
    ai_analysis = analyze_resume(resume_text)
    score, feedback = generate_feedback(resume_text, ai_analysis)

    ddb = boto3.resource('dynamodb')
    table = ddb.Table('CVScoreAI')
    table.put_item(Item={
        'ResumeID': key,
        'Score': score,
        'Feedback': feedback,
        'RawText': resume_text,
    })

    return {
        'statusCode': 200,
        'body': json.dumps('Resume scored and stored.')
    }
