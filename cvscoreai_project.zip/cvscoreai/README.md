
# CVScoreAI – Resume Analyzer using AWS Lambda + AI

## 🔧 What It Does
- Upload a resume (PDF) to S3
- Lambda triggers and uses:
  - Textract to extract text
  - OpenAI GPT to analyze and give feedback
  - Stores results in DynamoDB

## 📁 Setup Guide

### 1. Create S3 Bucket and Lambda Trigger
- Enable S3 event for `.pdf` upload

### 2. Create DynamoDB Table
- Name: `CVScoreAI`, Primary key: `ResumeID`

### 3. Create Lambda Function
- Upload zipped code or use `deploy/deploy.sh`

### 4. Set Environment Variable
- `OPENAI_API_KEY` in Lambda configuration

## 📌 Example Output
- Score: 78
- Feedback: "Strong skills in Python and AWS. Lacks mention of CI/CD tools. Add metrics to achievements."
