
#!/bin/bash
cd lambda_function
pip install -r requirements.txt -t .
zip -r9 ../cvscoreai.zip .
cd ..
aws lambda update-function-code --function-name cvscoreai --zip-file fileb://cvscoreai.zip
